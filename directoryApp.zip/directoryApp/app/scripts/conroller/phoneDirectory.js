'use strict';

var app = angular.module('phoneDirectory');
app.controller('phoneDirectoryCtrl', function ($scope) {
    $scope.deleteUser = -1;
    $scope.isSubmitted = 0;
    $scope.user = {};
    $scope.contacts = [{
        id:0,
        fName: "akshay",
        lName: "kamble",
        email: "kambleakshayd@gmail.com",
        phno: "7387461731",
        status: "Active",
        isDeleted:false
    }];

    $scope.addContact = function (valid,user) {
        
        if ((user.status != '' && user.status != undefined) && (valid)) {

            if (Number.isInteger(user.id)) {
                $scope.contacts[user.id] = user;
            } else {
                user.isDeleted = false;
                user.id = $scope.contacts.length;
                $scope.contacts.push(user);
                
            }
            $scope.user = {};
            $scope.isSubmitted = 0;
            $('#myModal').modal("hide")
        } else {
            $scope.isSubmitted = $scope.isSubmitted + 1;
        }
    }

    $scope.editContact = function (per) {
        $scope.user = Object.assign({}, per);
        $('#myModal').modal("show")
    }


    $scope.getConfirmation = function (id) {
        $scope.deleteUser = id;
        $('#deleteModal').modal("show")
    }
    $scope.deleteNow = function () {
        $scope.contacts[$scope.deleteUser].isDeleted = true;

    }
});