
var app = angular.module("phoneDirectory", ["ngRoute"]);
app.config(function ($routeProvider) {
    
    $routeProvider
        .when('/phoneDirectory', {
            templateUrl: 'app/views/phoneDirectory.html',
            controller: 'phoneDirectoryCtrl',
            controllerAs: 'phnoCtrl'
        })
        .otherwise({
            redirectTo: '/phoneDirectory'
        });
});